from datetime import datetime, date
import json

def json_encoder(obj):
    if isinstance(obj, (date, datetime)):
        return obj.isoformat()
    if isinstance(obj, dict):
        return {name: json_encoder(item) for name, item in obj.items()}
    if isinstance(obj, list):
        return [json_encoder(item) for item in obj]
    return obj


# Decode date and datetime object in string with isoformat
def json_decoder(obj):
    try:
        return datetime.fromisoformat(obj)
    except:
        if isinstance(obj, dict):
            return {name: json_decoder(item) for name, item in obj.items()}
        if isinstance(obj, list):
            return [json_decoder(item) for item in obj]
    return obj

def save(headers, data):
    with open('test.bin', 'ab') as f:
        f.write(json.dumps((headers, data), default=json_encoder))
        f.write('\r\n')

def read():
    with open('test.bin', 'b') as
