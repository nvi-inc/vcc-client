import functools
import json
import logging
import logging.handlers
import uuid
import jwt
from time import time
from base64 import b64decode
from urllib.parse import quote, urljoin
from cryptography.hazmat.primitives import serialization

from datetime import datetime

import requests
import toml
from Crypto.Cipher import AES
from sshtunnel import (BaseSSHTunnelForwarderError,
                       HandlerSSHTunnelForwarderError, SSHTunnelForwarder)

from vcc import (VCCError, json_encoder, make_object, settings, vcc_groups)

logger = logging.getLogger('vcc')


class API:
    def __init__(self, group_id, config):
        self.base_url = f'{config["protocol"]}://{config["url"]}:{config["port"]}'
        self.session = requests.Session()
        self.group_id = group_id
        self.code, self.uid = getattr(settings.Signatures, group_id)
        self.secret_key = str(uuid.uuid4())
        self.private_key = self.load_private_key()
        self.jwt_data = None

    def close(self):
        try:
            if self.session:
                self.session.close()
        finally:
            self.session = None


def load_private_key():
    with open(settings.RSAkey.path, 'rb') as f:
        return serialization.load_ssh_private_key(f.read(), password=None)


def validate_group(group_id):
    if not group_id:
        for group_id in vcc_groups:
            if hasattr(settings.Signatures, group_id):
                break
        else:
            raise VCCError('No valid groups in configuration file')
    if not (info := getattr(settings.Signatures, group_id)):
        raise VCCError(f'{group_id} is not a valid group')
    return group_id, info[0], info[1]


# Class to connect to VCC Web Service
class VCC:
    def __init__(self, group_id=None):
        self.group_id, self.code, self.uid = validate_group(group_id)
        # Initialize communication parameters
        self.base_url = self.url = self.protocol = None
        self.name, self.tunnel, self.port = '', None, 0
        self.http_session = None

        self.secret_key = str(uuid.uuid4())
        self.private_key = load_private_key()
        self.jwt_data = None

    # Enter function when 'with' is used
    def __enter__(self):
        self.connect()
        return self

    # Exit function when 'with' is used
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def make_signature(self, exp=120, data=None):
        required = {'code': self.code, 'group': self.group_id, 'secret': self.secret_key, 'exp': time() + exp}
        data = dict(**data, **required) if data else required
        return {'token': jwt.encode(data, self.private_key, algorithm='RS256', headers={'uid': self.uid}),
                'utc': datetime.utcnow().isoformat()}

    def validate_signature(self, rsp):
        if not (token := rsp.headers.get('token')):
            return None
        if not (headers := jwt.get_unverified_header(token)) or headers.get('uid') != self.uid:
            raise VCCError('Invalid token')
        try:
            return jwt.decode(token, self.secret_key, algorithms=headers['alg'])
        except (jwt.exceptions.ExpiredSignatureError, jwt.exceptions.InvalidSignatureError) as exc:
            raise VCCError(f'invalid token {str(exc)}')

    def start_tunnel(self, name, config, test=False):
        if name == self.name and self.tunnel:
            self.tunnel.check_tunnels()
            if not self.tunnel.tunnel_is_up:
                self.tunnel.restart()
            return self.name, self.tunnel
        tunnel = SSHTunnelForwarder(config.url, ssh_username=config.tunnel, ssh_pkey=config.key,
                                    remote_bind_address=('localhost', config.port))
        tunnel.daemon_forward_servers = True
        tunnel.start()
        self.url, self.port = 'localhost', tunnel.local_bind_port
        if test:
            tunnel.check_tunnels()

        return name, tunnel

    def tunnel_is_up(self):
        if not self.tunnel:
            return False
        self.tunnel.check_tunnels()
        return all(list(self.tunnel.tunnel_is_up.values()))

    # Get first available VWS client
    def connect(self):
        logger.debug('connecting')
        # Get list of VLBI Communications Center (VCC)
        for name, config in get_server():
            self.url, self.protocol, self.port = config.url, config.protocol, config.port
            if getattr(config, 'tunnel', None):
                logger.debug('tunnel start')
                try:
                    self.name, self.tunnel = self.start_tunnel(name, config)
                except (BaseSSHTunnelForwarderError, HandlerSSHTunnelForwarderError):
                    logger.debug('tunnel problem')
                    continue
            #Init http session
            self.http_session = requests.Session()
            self.base_url = f'{self.protocol}://{self.url}:{self.port}'
            # Test VCC API can be reached
            if self.is_available:
                return

        self.close()
        raise VCCError('cannot connect to any VCC')

    def close(self):
        try:
            if self.tunnel:
                self.tunnel.stop()
            if self.http_session:
                self.http_session.close()
        finally:
            self.tunnel = self.http_session = None

    @property
    def config(self):
        return {'url': self.url, 'protocol': self.protocol, 'port': self.port}

    @property
    # Check if site is available by requesting a welcome message
    def is_available(self):
        try:
            if self.http_session:
                rsp = self.api.get('/', timeout=5)  # Not more than 5 seconds to look for vcc
                return 'Welcome to VLBI Communications Center' in rsp.text if rsp else False
        except:
            pass
        return False

    # GET data from web service
    def get(self, path, params=None, headers=None, timeout=None):
        try:
            headers = dict(**(headers or {}), **self.make_signature())
            rsp = self.http_session.get(url=urljoin(self.base_url, path), params=params, headers=headers,
                                        timeout=timeout)
            self.jwt_data = self.validate_signature(rsp) if rsp and path != '/' else None
            return rsp
        except requests.exceptions.ConnectionError as exc:
            logging.debug(str(exc))
            raise VCCError(f'connect error')

    # POST data to web service
    def post(self, path, data=None, files=None, headers=None, params=None):
        try:
            headers = dict(**(headers or {}), **self.make_signature())
            rsp = self.http_session.post(url=urljoin(self.base_url, path), json=json_encoder(data), files=files,
                                         params=params, headers=headers)
            self.jwt_data = self.validate_signature(rsp) if rsp else None
            return rsp
        except requests.exceptions.ConnectionError:
            raise VCCError('connect error')

    # PUT data to web service
    def put(self, path, data=None, files=None, headers=None):
        try:
            headers = dict(**(headers or {}), **self.make_signature())
            rsp = self.http_session.put(url=urljoin(self.base_url, path), json=json_encoder(data), files=files,
                                        headers=headers)
            self.jwt_data = self.validate_signature(rsp) if rsp else None
            return rsp
        except requests.exceptions.ConnectionError:
            raise VCCError('connect error')

    # DELETE data from web service
    def delete(self, path, headers=None):
        try:
            headers = dict(**(headers or {}), **self.make_signature())
            rsp = self.http_session.delete(url=urljoin(self.base_url, path), headers=headers)
            self.jwt_data = self.validate_signature(rsp) if rsp else None
            return rsp
        except requests.exceptions.ConnectionError:
            raise VCCError('connect error')


def get_server():
    def _decode(item):
        key, val = item.split(':')
        try:
            return key, int(val)
        except ValueError:
            return key, val

    for name, info in settings.Servers.__dict__.items():
        config = dict([_decode(item) for item in info.split(',')]+[('key', settings.RSAkey.path)])
        yield name.lower(), make_object(config)
