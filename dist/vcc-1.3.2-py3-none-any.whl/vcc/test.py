import json
import math
import sys
from datetime import datetime, timedelta
import threading
import queue

from tkinter import *
from tkinter import ttk, scrolledtext

from vcc import settings, VCCError, json_decoder, groups
from vcc.server import VCC
from vcc.session import Session
from vcc.messaging import RMQclientException


class Inbox(threading.Thread):

    def __init__(self, ses_id, vcc, messages):
        super().__init__()

        self.rmq_client, self.messages = vcc.get_rmq_client(ses_id), messages

    def run(self):
        try:
            self.rmq_client.monit(self.process_message)
        except RMQclientException as exc:
            pass

    def stop(self):
        self.rmq_client.close()

    def process_message(self, headers, data):
        self.messages.put((headers, data))  # Send message to dashboard
        self.rmq_client.acknowledge_msg()  # Always acknowledge message


# Class to display SEFD for specific station
class SEFDViewer:
    def __init__(self, app, data):
        self.app, self.data, self.top = app, data, None

    def show(self):
        if not self.top:
            self.top = Toplevel(self.app.root, padx=10, pady=10)
            self.top.title(f'SEFD {self.data["sta_id"]}')
            self.init_observed()
            self.init_detectors()
            self.top.geometry("420x500")
            self.top.protocol("WM_DELETE_WINDOW", self.done)

        self.top.focus()

    def init_observed(self):
        frame = LabelFrame(self.top, text='Observed', padx=5, pady=5)
        # Reason label and OptionMenu
        Label(frame, text=f'Source: {self.data["source"]}',
              anchor='w').grid(row=0, column=0, padx=5, pady=5, sticky='ew')
        Label(frame, text=f'Az: {self.data["azimuth"]}').grid(row=0, column=1, padx=5, pady=5, sticky='ew')
        Label(frame, text=f'El: {self.data["elevation"]}').grid(row=0, column=2, padx=5, pady=5, sticky='ew')
        Label(frame, text=f'{self.data["observed"]:%Y-%m-%d %H:%M}',
              anchor='e').grid(row=0, column=3, padx=5, pady=5, sticky='we')
        for col in range(4):
            frame.columnconfigure(col, weight=1)
        frame.pack(expand=NO, fill=BOTH)

    def init_detectors(self):
        header = {'De': (50, W, NO), 'I': (20, CENTER, NO), 'P': (20, CENTER, NO), 'Freq': (75, E, NO),
                  'TSYS': (75, E, NO), 'SEFD': (75, E, YES)}
        width, height = sum([info[0] for info in header.values()]), 150
        frame = LabelFrame(self.top, text='Detectors', height=height, width=width + 20, padx=5, pady=5)
        # Add a Treeview widget
        tree = ttk.Treeview(frame, column=list(header.keys()), show='headings', height=15)
        tree.place(width=width, height=height)
        names = ['device', 'input', 'polarization', 'frequency', 'tsys', 'sefd']
        for info in self.data['detectors']:
            tree.insert('', 'end', info['device'], values=[info[name] for name in names])
        vsb = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        vsb.place(width=20, height=height)
        vsb.pack(side='right', fill='y')
        tree.configure(yscrollcommand=vsb.set)
        tree.tag_configure('cancelled', background="red")

        for col, (key, info) in enumerate(header.items(), 0):
            tree.column(f"{col}", anchor=info[1], minwidth=0, width=info[0], stretch=info[2])
            tree.heading(f"{col}", text=key)
        tree.pack(expand=YES, fill=BOTH)
        frame.pack(expand=YES, fill=BOTH)

    def done(self):
        self.top.destroy()
        self.top = None


class StationLog:
    def __init__(self, app, sta_id):
        self.app, self.sta_id, self.top = app, sta_id, None
        self.box, self.text = None, StringVar()
        self.data = []

    def show(self):
        if not self.top:
            self.top = Toplevel(self.app.root, padx=10, pady=10)
            self.top.title(f'{self.sta_id} - events')
            self.box = scrolledtext.ScrolledText(self.top, font=("TkFixedFont",))
            self.box.pack(expand=TRUE, fill=BOTH)
            self.box.configure(state='disabled')
            self.top.geometry("450x200")
            self.top.protocol("WM_DELETE_WINDOW", self.done)
            self.app.root.after(1000, self.add_line)
        self.top.focus()

    def done(self):
        self.top.destroy()
        self.top = None

    def add(self, text, utc=datetime.utcnow()):
        self.data.append((utc, text))
        self.box.configure(state='normal')
        self.box.insert(END, f'{utc:%Y-%m-%d %H:%M:%S} - {text}\n')
        self.box.configure(state='disabled')

    def add_line(self):
        self.add('This is a test', datetime.utcnow())
        self.app.root.after(1000, self.add_line)


# Dashboard displaying session activities.
class Dashboard:

    def __init__(self, ses_id):
        self.vcc = VCC('DB')
        self.session = self.get_session(ses_id)
        self.root = Tk()
        self.root.protocol("WM_DELETE_WINDOW", self.done)
        self.network, self.start, self.status_text, self.schedule = StringVar(), StringVar(), StringVar(), StringVar()
        self.utc = StringVar()

        self.network.set(self.session.network)
        self.start.set(f'{self.session.start:%Y-%m-%d %H:%M}')
        self.status = self.st_label = None
        self.stations = None
        self.timer = None  # Timer(self.utc, self.update_status)
        self.stopped = threading.Event()
        self.sefds = {}
        self.messages = queue.Queue()
        self.inbox = Inbox(ses_id, self.vcc, self.messages)
        self.logs = {sta_id: StationLog(self, sta_id) for sta_id in self.session.network}

    def check_maximize(self, event):
        print('event', event)

    def init_wnd(self):
        # Set the size of the tkinter window
        self.root.title(f'VLBI Dashboard V1.0')

        style = ttk.Style(self.root)
        style.theme_use('clam')
        style.map('W.Treeview', background=[('selected', 'white')], foreground=[('selected', 'black')])
        # Add a frame for TreeView
        main_frame = Frame(self.root, padx=5, pady=5)
        self.init_session(main_frame)
        self.init_stations(main_frame)
        self.init_done(main_frame)
        main_frame.pack(expand=YES, fill=BOTH)
        self.root.geometry("750x330")

    def init_session(self, main_frame):
        frame = LabelFrame(main_frame, text=self.session.code.upper(), padx=5, pady=5)
        # Reason label and OptionMenu
        Label(frame, text="Network", anchor='w').grid(row=0, column=0, padx=10, pady=5)
        Label(frame, textvariable=self.network, borderwidth=2, relief="sunken"
              , anchor='w').grid(row=0, column=1, columnspan=5, padx=5, pady=5, sticky='we')
        Label(frame, text="Start time", anchor='w').grid(row=1, column=0, padx=5, pady=5)
        self.st_label = Label(frame, textvariable=self.start, anchor='w', relief='sunken')
        self.st_label.grid(row=1, column=1, columnspan=2, padx=5, pady=5, sticky='we')
        self.status = Label(frame, textvariable=self.status_text, anchor='w', relief='sunken')
        self.status.grid(row=1, column=4, columnspan=2, padx=5, pady=5, sticky='we')
        Label(frame, text="Schedule", anchor='w').grid(row=2, column=0, padx=5, pady=5)
        Label(frame, textvariable=self.schedule, anchor='w', relief='sunken'
              ).grid(row=2, column=1, columnspan=3, padx=5, pady=5, sticky='we')
        for col in range(5):
            frame.columnconfigure(col, uniform='a')

        frame.columnconfigure(5, weight=1)
        frame.pack(expand=NO, fill=BOTH)

    def change_color(self):
        self.network.set('K2 Oe Ws -Ow')
        self.nw_label.configure(fg='red')

    def station_clicked(self, event):
        row, col = self.stations.identify_row(event.y), self.stations.identify_column(event.x)
        if row:
            if col == '#3' and self.sefds.get(row):
                self.sefds[row].show()
            elif col == '#5':
                self.logs[row].show()

    def sefd_closed(self, sta_id):
        print('child closed', sta_id)

    def init_stations(self, main_frame):
        header = {'Station': (75, W, NO), 'Schedule': (100, CENTER, NO), 'SEFD': (150, CENTER, NO),
                  'Scans': (100, W, NO), 'Status': (600, W, YES)}
        width, height = sum([info[0] for info in header.values()]), 150
        frame = Frame(main_frame, height=height, width=width+20)
        # Add a Treeview widget
        self.stations = ttk.Treeview(frame, column=list(header.keys()), show='headings', height=5, style='W.Treeview')
        self.stations.place(width=width, height=height)

        vsb = ttk.Scrollbar(frame, orient="vertical", command=self.stations.yview)
        vsb.place(width=20, height=height)
        vsb.pack(side='right', fill='y')
        self.stations.configure(yscrollcommand=vsb.set)
        self.stations.tag_configure('cancelled', background="red")

        for col, (key, info) in enumerate(header.items(), 0):
            self.stations.column(f"{col}", anchor=info[1], minwidth=0, width=info[0], stretch=info[2])
            self.stations.heading(f"{col}", text=key)

        for sta in self.session.network:
            self.stations.insert('', 'end', sta.capitalize(), values=(sta.capitalize(), 'None', ), tags=('all',))
        self.stations.tag_configure('all', background='white')
        self.stations.bind('<ButtonRelease-1>', self.station_clicked)
        self.stations.pack(expand=YES, fill=BOTH)
        frame.pack(expand=YES, fill=BOTH)

    def init_done(self, main_frame):
        frame = Frame(main_frame, padx=5, pady=5)
        button = Button(frame, text="Done", command=self.done)
        button.pack(side=LEFT)
        Label(frame, textvariable=self.utc, anchor='e', font=("TkFixedFont",)).pack(side=RIGHT)
        frame.configure(height=button.winfo_reqheight()+10)
        frame.pack(expand=NO, fill=BOTH)

    def update_status(self, utc):
        status = self.session.get_status()
        if status == 'waiting':
            dt = (self.session.start - utc).total_seconds()
            if dt > 3600:
                hours, minutes = divmod(int(dt / 60), 60)
                text = f'Starting in {hours:d} hour{"s" if hours > 1 else ""} and {minutes:02d} minutes'
            elif dt > 60:
                minutes = math.ceil(dt / 60)
                text = f'Starting in {minutes:d} minute{"s" if minutes > 1 else ""}'
            else:
                seconds = math.ceil(dt)
                s = 's' if seconds > 1 else ''
                text = f'Starting in {seconds:02d} second{"s" if seconds > 1 else ""}'

            color = 'black' if dt > 600 else 'red'
        else:
            color, text = 'black', status.capitalize()
        self.status_text.set(text)
        self.status.configure(fg=color)

    def get_session(self, ses_id):
        rsp = self.vcc.get_api().get(f'/sessions/{ses_id}')
        if not rsp:
            raise VCCError(f'{ses_id} not found')
        return Session(json_decoder(rsp.json()))

    def get_sefds(self, sta_id):
        rsp = self.vcc.get_api().get(f'/data/onoff/{sta_id.lower()}')
        if rsp:
            data = json_decoder(rsp.json())
            self.sefds[sta_id] = SEFDViewer(self, data)
            self.stations.set(sta_id.capitalize(), '#3', f'{data["observed"]:%Y-%m-%d %H:%M}')

    def get_schedule(self):
        rsp = self.vcc.get_api().get(f'/schedules/{self.session.code.lower()}', params={'select': 'summary'})
        if rsp:
            data = json_decoder(rsp.json())
            self.session.update_schedule(data)
            self.schedule.set(self.session.sched_version)

    def done(self):
        try:
            self.inbox.stop()
            print('Waiting for inbox')
            self.inbox.join()
            self.root.destroy()
            print('Destroyed')
        except Exception as exc:
            print('done problem', str(exc))
            sys.exit(0)

    def run_timer(self):
        waiting_time = 1.0 - datetime.utcnow().timestamp() % 1
        try:
            while not self.stopped.is_set():
                dt = datetime.utcnow().timestamp() % 1
                waiting_time = 1.0 if dt < 0.001 else 1.0 - dt
                print('waiting', waiting_time)
                threading.Event().wait(waiting_time)
                utc = datetime.utcnow()
                self.utc.set(f'{utc:%Y-%m-%d %H:%M:%S} UTC')
                self.update_status(utc)
                print('next')
        except Exception as exc:
            print('while loop', str(exc))

        print('End of timer')

    def update_clock(self):
        utc = datetime.utcnow()
        self.utc.set(f'{utc:%Y-%m-%d %H:%M:%S} UTC')
        self.update_status(utc)
        dt = datetime.utcnow().timestamp() % 1
        waiting_time = 1.0 if dt < 0.001 else 1.0 - dt
        self.root.after(int(waiting_time*1000), self.update_clock)

    def update_station_info(self, sta_id, col, text, utc=datetime.utcnow()):
        self.stations.set(sta_id, col, text)

    def process_sta_info(self, headers, data):
        sta_id = data.get('station', None)
        sta_id = sta_id.capitalize() if sta_id else headers.get('sender', '__').capitalize()

        ses_id = data.get('session', None)
        ses_id = ses_id.upper() if ses_id else headers.get('session', '__').upper()

        # Check if valid station and session id
        if sta_id not in self.session.network or (ses_id not in ['__', self.session.code.upper()]):
            return
        if 'sefd' in data:
            self.get_sefds(station=sta_id)
        elif 'status' in data:
            text = data['status']
            if 'ses-info' in text:
                text = text.replace('ses-info:', '').replace(data['session'], '').replace(',,', ',')
            text = text[1:] if text.startswith(',') else text
            print(datetime.now(), text, headers['utc'])
            self.update_station_info(sta_id, '#5', text, datetime.fromisoformat(headers['utc']))
            # self.update_scans(sta_id, data)
        elif 'schedule' in data:
            self.update_station_info(sta_id, '#5', f'V{data["version"]} fetched')
            self.update_station_info(sta_id, '#2', f'V{data["version"]}')

    def process_master(self, headers, data):
        status = data.get(self.session.code.upper(), None)
        if status == 'cancelled':
            print(self.session.code, status)
        elif status == 'updated':
            print(self.session.code, status)

    def process_messages(self):
        while not self.messages.empty():
            headers, command = self.messages.get()
            print(headers, command)
            # Decode command
            if headers['format'] == 'json':
                command = json.loads(command)
                text = ', '.join([f'{key}={val}' for key, val in command.items()])
            else:
                text = command
            code = headers['code']
            msg, name = f'{code} {text}', f'process_{code}'
            print(msg, name)
            # Call function for this specific code
            if hasattr(self, name):
                getattr(self, name)(headers, command)

        self.root.after(100, self.process_messages)

    def exec(self):
        self.init_wnd()
        threading.Thread(target=self.get_schedule).start()
        for sta_id in self.session.network:
            threading.Thread(target=self.get_sefds, args=(sta_id,)).start()
        self.inbox.start()
        dt = datetime.utcnow().timestamp() % 1
        waiting_time = 1.0 if dt < 0.001 else 1.0 - dt
        self.root.after(int(waiting_time*1000), self.update_clock)
        self.root.after(100, self.process_messages)
        self.root.mainloop()


def test(value, stop):
    waiting_time = 1.0 - datetime.utcnow().timestamp() % 1
    while not stop.wait(waiting_time):
        utc = datetime.utcnow()
        value.set(f'{utc:%Y-%m-%d %H:%M:%S} UTC')
        dt = datetime.utcnow().timestamp() % 1
        waiting_time = 1.0 if dt < 0.001 else 1.0 - dt

def main():
    import argparse

    parser = argparse.ArgumentParser(description='Edit Station downtime')
    parser.add_argument('-c', '--config', help='config file', required=False)
    parser.add_argument('session', help='station code', nargs='?')

    args = settings.init(parser.parse_args())

    try:
        Dashboard(args.session).exec()
    except VCCError as exc:
        messagebox.showerror(f'{args.session.upper()} failed', str(exc))

if __name__ == '__main__':

    sys.exit(main())
